# Appendix
Here are some workflow diagrams for reference.

## Data Analysis Workflow
<img src="data_analysis_workflow.png?raw=true" align="center" width="600" alt="data analysis workflow">

## Choosing the Appropriate Plot
<img src="choosing_the_appropriate_plot_flow_chart.png?raw=true" align="center" width="600" alt="choosing the appropriate plot">

## Machine Learning Workflow
<img src="ml_workflow.png?raw=true" align="center" width="600" alt="machine learning workflow">
